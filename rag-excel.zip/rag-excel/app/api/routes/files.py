from fastapi import APIRouter
from typing import Any, Union
from app.models import FileResponse, FileRequest
import logging
from fastapi.responses import StreamingResponse
import ollama
from app.services.data_analysis_service import DataAnalysisService


logger = logging.getLogger(__name__)
router = APIRouter()

# TODO - colocar o mongodb para gerenciar os arquivos


@router.post("/files", response_model=FileResponse)
def insert_file(__payload: Union[FileRequest, None] = None) -> Any:
    print(f"incluindo o arquivo: {__payload.file_name}")
    return FileResponse(
        weaviate_id= "dsadf",
        user_id="rogerio.rodrigues"
    )

@router.get("/files", response_model=FileResponse)
def get_files() -> Any:
    return FileResponse(
        weaviate_id= "dsadf",
        user_id="rogerio.rodrigues"
    )
