
cors_origins = [
    "*"
]